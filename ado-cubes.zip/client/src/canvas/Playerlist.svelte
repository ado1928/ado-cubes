<script>
	import Box from "lib/Box.svelte";
</script>

<Box id="playerlist" classes="center hide">
	
</Box>