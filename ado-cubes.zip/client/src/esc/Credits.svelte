<main class="credits">
	<section>
		<img src="./img/logo/adocubes-text.svg" alt="adocubes">
	</section>

	<section>
		<h1>developers</h1>
		<table>
			<tr>
				<td><img src="/img/icon/credits/Ado1928.png"></td>
				<td><a href="https://github.com/ado1928">Ado1928</a><br>Creator</td>
				<td><img src="/img/icon/credits/ifritdiezel.png"></td>
				<td><a href="https://github.com/ifritdiezel">ifritdiezel</a><br>Back-End</td>
				<td><img src="/img/icon/credits/macimas.png"></td>
				<td><a href="https://github.com/macimas">macimas</a><br>Front-End</td>
			</tr>
		</table>
	</section>

	<section>
		<h1>contributors</h1>
		<table>
			<tr>
				<td>
					<a href="https://github.com/hyxud">hyxud</a><br>
					Mouse placing
				</td>
				<td> 
					<a href="https://github.com/QmelZ">QmelZ</a><br>
					Settings
				</td>
			</tr>
		</table>
	</section>

	<section>
		<h1>made with</h1>
		<table>
			<tr>
				<td><img src="./img/icon/credits/three.js.png"></td>
				<td><a href="https://threejs.org">Three.js</a><br>Game</td>
				<td><img src="./img/icon/credits/node.js.png"></td>
				<td><a href="https://nodejs.org">Node.js</a><br>Back-End</td>
				<td><img src="./img/icon/credits/svelte.png"></td>
				<td><a href="https://svelte.dev">Svelte</a><br>Front-End</td>
			</tr>
		</table>

		<br>
		
		<p>Sounds generated with <a href="https://sfxr.me">jsfxr</a></p>
		<!--<p>Music by Kevin MacLeod (from <a href="https://incompetech.com">incompetech.com</a>)</p>
		<p>"Chill", "Ether Vox", "Look Busy",<br>"Northen Glade", "Pixel Peeker Polka - faster"</p>
		<p>Licensed under Creative Commons: By Attribution 4.0 License</p>
		<p>http://creativecommons.org/licenses/by/4.0/</p>-->
	</section>
</main>