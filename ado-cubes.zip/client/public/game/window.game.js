// terrible
window.game = {
	socket: socket,

	cubeType: 'basic',
	buildingMethod: 'raycast',
	movementMethod: 'fly'
}